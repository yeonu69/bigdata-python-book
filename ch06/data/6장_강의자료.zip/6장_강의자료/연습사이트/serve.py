"""공기 기록 연습장을 켠다:  python serve.py [포트]   (기본 8000)

- 정적 파일(html, json, robots.txt)을 그대로 보내 준다.
- User-Agent가 비었거나 'python-'으로 시작하면(라이브러리 기본값) 403으로 거절한다.
- /api/headers 는 서버가 받은 요청 머리글을 JSON으로 되돌려 준다.
"""
import json, os, sys
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, *args):          # 요청마다 찍히는 기록은 끈다
        pass

    def do_GET(self):
        ua = self.headers.get("User-Agent", "")
        if self.path != "/robots.txt" and (ua == "" or ua.lower().startswith("python-")):
            body = ("<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>403</title></head>"
                    "<body><h1>403 거절</h1><p>User-Agent에 이름과 목적을 적어 주세요.</p></body></html>").encode()
            self.send_response(403)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path == "/api/headers":
            body = json.dumps(dict(self.headers), ensure_ascii=False).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()

    def guess_type(self, path):
        t = super().guess_type(path)
        return t + "; charset=utf-8" if t.startswith("text/") or t.endswith("json") or t.endswith("javascript") else t

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"공기 기록 연습장: http://localhost:{port}/")
    ThreadingHTTPServer(("", port), partial(Handler, directory=HERE)).serve_forever()

// 페이지가 열린 뒤 JSON을 받아 날마다 PM2.5 꺾은선을 그린다 (브라우저에서만 실행된다)
(function () {
  var box = document.getElementById('daily');
  fetch(box.dataset.src).then(function (r) { return r.json(); }).then(function (d) {
    var v = d.daily.map(function (x) { return x.pm25; });
    var w = 720, h = 200, mx = Math.max.apply(null, v.filter(function (x) { return x !== null; }));
    var pts = v.map(function (y, i) { return y === null ? null : (i * w / (v.length - 1)).toFixed(1) + ',' + (h - y * h / mx).toFixed(1); })
               .filter(function (p) { return p; }).join(' ');
    box.innerHTML = '<svg width="' + w + '" height="' + h + '"><polyline fill="none" stroke="#C8234B" points="' + pts + '"/></svg>' +
                    '<p>' + d.station + ' 측정소, ' + d.daily.length + '일, 가장 높은 날 ' + mx + ' ' + d.unit + '</p>';
  });
})();
